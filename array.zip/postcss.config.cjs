module.exports = {
  plugins: {
    'postcss-import': {},
    'postcss-mixins': {},
    tailwindcss: {},
    autoprefixer: {},
  }
}