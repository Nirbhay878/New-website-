/* -----------------------------------------------------------------------------
CSS imports & Polyfill
----------------------------------------------------------------------------- */
import '../css/main.css';
import '../css/ghost.css';
import '../css/theme.css';

import 'vite/modulepreload-polyfill'

/* -----------------------------------------------------------------------------
Alpine Js
----------------------------------------------------------------------------- */
import Alpine from 'alpinejs'
window.Alpine = Alpine
Alpine.start()

/* -----------------------------------------------------------------------------
Tocbot
----------------------------------------------------------------------------- */
import tocbot from 'tocbot';
window.tocbot = tocbot

/* -----------------------------------------------------------------------------
Custom functions
----------------------------------------------------------------------------- */
import { 
  copyURL,
  toggleSubmenu,
  closeSubmenus,
  getScrollPercent,
  setTagAccentColor,
  toggleMembershipPlan,
  calculateDiscounts,
  renderTOC
} from './utils';

window.copyURL = copyURL
window.toggleSubmenu = toggleSubmenu
window.closeSubmenus = closeSubmenus
window.getScrollPercent = getScrollPercent
window.setTagAccentColor = setTagAccentColor
window.toggleMembershipPlan = toggleMembershipPlan
window.calculateDiscounts = calculateDiscounts
window.renderTOC = renderTOC

import { getContentApi } from './ghost';
window.getContentApi = getContentApi

/* -----------------------------------------------------------------------------
Fitvids
----------------------------------------------------------------------------- */
import fitvids from 'fitvids';
window.Fitvids = fitvids
Fitvids();